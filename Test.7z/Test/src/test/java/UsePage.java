import org.openqa.selenium.WebDriver;

class UserPage {

    WebDriver driver;

    UserPage(WebDriver driver) {
        this.driver = driver;
    }

}
